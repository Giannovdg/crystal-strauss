"use client"

import Component from "../next-blocks"

export default function SyntheticV0PageForDeployment() {
  return <Component />
}